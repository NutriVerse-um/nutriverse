from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/img'

def home():
    return render_template('index.html')

def calculate_bmi(weight, height):
    return round(weight / ((height / 100) ** 2), 2)

def get_status(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 25:
        return "Ideal"
    else:
        return "Obesitas"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form['name']
        weight = float(request.form['weight'])
        height = float(request.form['height'])

        bmi = calculate_bmi(weight, height)
        status = get_status(bmi)

        conn = sqlite3.connect('nutriverse.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS data 
                     (name TEXT, weight REAL, height REAL, bmi REAL, status TEXT)''')
        c.execute('INSERT INTO data VALUES (?, ?, ?, ?, ?)',
                  (name, weight, height, bmi, status))
        conn.commit()
        conn.close()

        return render_template('index.html', name=name, bmi=bmi, status=status)
    return render_template('index.html', status="default")

@app.route('/result', methods=['POST'])
def result():
    try:
        weight = float(request.form['weight'])
        height = float(request.form['height']) / 100 # convert cm to m
        age = int(request.form['age'])
    except:
        return redirect(url_for('home'))
    
    bmi = weight / (height ** 2)
    bmi_rounded = round(bmi, 2)

    # redirect ke result.html dengan parameter
    return redirect(url_for('show_result', bmi=bmi_rounded, age=age))

@app.route('/show_result')
def show_result():
    bmi = request.args.get('bmi', type=float)
    age = request.args.get('age', type=int)
    if bmi is None or age is None:
        return redirect(url_for('index'))
    return render_template('result.html', bmi=bmi, age=age)

if __name__ == '__main__':
    app.run(debug=True)
